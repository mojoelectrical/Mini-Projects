﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Contracts;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;
using System.IO;


namespace MichaelAsafo301110711
{
    class Patient
    {

        private List<Prescription> prescriptions = new List<Prescription>();

        public List<Prescription> Prescription
        {
             get { return prescriptions; }
            set { prescriptions = value; }
        }

        public string Name { get; private set;}
        public int Yob { get; private set; }

        public Patient(string name, int yob) {
            this.Name = name;
            this.Yob = yob;
        }
        string all;
        public int t = 0;
        public void AddPrescription(Prescription prescription) {
            Prescription.Add(prescription);
        }

        public string GetPrescriptions() {
            
            foreach (Prescription pre in prescriptions) {
                all += prescriptions.ToString();
                all += "\n";       
            }
            return all;
        }
        public string filepath;
        public void RemovePrescription(string id) {
            try
            {

                foreach (Prescription pre in prescriptions)
                {
                    if (id.Equals(pre.ID))
                    {
                        prescriptions.RemoveAt(t);
                        t++;
                    }
                    else { throw new Exception("ID does not match"); }
                }
            }
            catch(Exception e) {
                Console.WriteLine(e.Message());
            
            }
        }

        public void SaveAsText(string filename) {
            string file = filename;
            string filepath = @"{file}";

            List<string> lines = new List<string>();
            foreach (var prescriptions in Prescription) {
                Console.WriteLine(prescriptions.ToString());
                lines.Add(prescriptions.ToString());
            }

            File.WriteAllLines(filepath, lines);
        }

        public override string ToString()
        {
           string l= $"{Name} yob: {Yob}\n";
            l += GetPrescriptions();

            return l;
        }

       








    }
}
