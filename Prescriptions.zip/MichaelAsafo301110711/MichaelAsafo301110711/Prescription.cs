﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MichaelAsafo301110711
{
    class Prescription
    {
        private static int CURRENT_NUMBER=100;
        public string ID { get; }

        public string Doctor { get; private set; }
        public bool ForRepeat { get; private set; }

        public int Length { get; private set; }

        public string Name { get; set; }

        public string status;
        public Prescription(string doctor, string name, int length, bool forRepeat = false){
            this.Doctor = doctor;
            this.Name = name;
            this.Length = length;
            this.ForRepeat = forRepeat;
            this.ID = CURRENT_NUMBER.ToString();
            CURRENT_NUMBER++;


        }

        public string getID() {
            return ID;
        }

        public override string ToString()
        {

            if (ForRepeat == false) {
                status = "No";
            }

            if (ForRepeat == true) {
                status = "Yes";
             }

            string output= $"#{CURRENT_NUMBER} {Name} prescribed by {Doctor} for {status} repeat) /n ";

            return output;
        }
    }
}
