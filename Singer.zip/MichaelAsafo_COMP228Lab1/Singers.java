public class Singers {
	//class for Singer
	    int singerId;                             //ID instance variable
	    String singerName;                        //Name instance variable
	    String singerAddress;                     // Address instance variable
	    String singerDOB;                         // DOB instance variable
	    int singerAmtAlbums;                      // Amount of Albums instance variable
	
	// Constructor with no arguments
	Singers(){
	    singerId= 4563432;
	    singerName="Rihanna";
	    singerAddress = "123 Hollywood Ave";
	    singerDOB= "06/23/1979";
	    singerAmtAlbums= 5;
	}
	//Constructor with 1 arguments
	Singers(int id){
	    singerId=id;
	    singerName="Rihanna";
	    singerAddress = "123 Hollywood Ave";
	    singerDOB= "06/23/1979";
	    singerAmtAlbums= 5;
	}
	//Constructor with 2 arguments
	Singers(int id, String singer_name){
	    singerId=id;
	    singerName=singer_name;
	    singerAddress = "123 Hollywood Ave";
	    singerDOB= "06/23/1979";
	    singerAmtAlbums= 5;
	}
	
	//Constructor with 3 arguments
	Singers(int id, String singer_name, String singer_address) {
	    singerId=id;
	    singerName=singer_name;
	    singerAddress = singer_address;
	    singerDOB= "06/23/1979";
	    singerAmtAlbums= 5;
	}
	
		//Constructor with 4 arguments
	Singers(int id, String singer_name, String singer_address, String DOB) {
	    singerId=id;
	    singerName=singer_name;
	    singerAddress = singer_address;
	    singerDOB= DOB;
	    singerAmtAlbums= 5;
	}
		//Constructor with 5 arguments
	Singers(int id, String singer_name, String singer_address, String DOB, int AlbumAmt){
	    singerId=id;
	    singerName=singer_name;
	    singerAddress = singer_address;
	    singerDOB= DOB;
	    singerAmtAlbums= AlbumAmt;
	}
	/*
	c) Create Setters and getters for all the instance variables of class Singer. Make sure to have
several setters that would allow you to set the values of individual instance variables of the
singer object. Also create one setter that would allow you to set all the values of the
instance variables at once. Create several getters that would allow you to get the current
individual values of each instance variables of the Singer object. [10 marks]
	*/
    public void setID(int id){
        this.singerId = id;                  //sets singer ID
    }
    public void setName(String name){
        this.singerName=name;      //sets singer Name
    }
    public void setAddress(String address){
        this.singerAddress=address;            // sets singer Address
    }
    public void setDOB(String dob){
        this.singerDOB=dob;                    // sets singer Date of Birth
    }
    
    public void setAmt(int Amt){
        this.singerAmtAlbums=Amt;           // sets singer's amount of albums
    }
	
	
	
	public void setAllSinger(int id, String name, String address, String dob, int Amt){
	    this.singerId=id;                                       //sets singer ID
	    this.singerName=name;                                   //sets singer Name
	    this.singerAddress=address;                            //sets singer address
	    this.singerDOB=dob;                                   //sets singer date of birth
	    this.singerAmtAlbums=Amt;                         //sets singer's amount of albums
	}
	
	/*GETTERS */
	public int getID(){
	    return singerId;
	}
	
	public String getName(){
	   return singerName;
	}
	
	public String getAddress(){
	    return singerAddress;
	}
	
	public String getDOB(){
	    return singerDOB;
	}
	
	public int getAmtAlbum(){
	    return singerAmtAlbums;
	}
	
	/*d) Create the driver class (SingerTest) that would create 1 Singer (singer1) object with the help
of the no argument constructor. Display the default values of the instance variables of this
object singer1. [5 marks]
e) Set the values of each instance varia es with the help of setters. Display the values. */
	

	}