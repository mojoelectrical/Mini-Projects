
public class SingerTest {

	public static void main(String[] args) {
		
		Singers singer1= new Singers();
		
		System.out.printf("%d%n%s%n%s%n%s%n%d%n", singer1.singerId,singer1.singerName,singer1.singerAddress,singer1.singerDOB,singer1.singerAmtAlbums);
		
		
		Singers singer2 =  new Singers();
		singer2.setID(3455124);
		singer2.setName("Kanye West");
		singer2.setAddress("123 Beverly Hills");
		singer2.setDOB("1/3/1977");
		singer2.setAmt(10);
		
		System.out.printf("%d%n%s%n%s%n%s%n%d%n", singer2.singerId,singer2.singerName, singer2.singerAddress, singer2.singerDOB, singer2.singerAmtAlbums);
		
		
		
		
	}
}
