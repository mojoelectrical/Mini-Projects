/*<!--  
Michael Asafo
301110711
2021/02/12
app.js
--> */
const express = require('express');
const path= require('path');

const app = express();

//Set static folder

app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine','ejs');
app.get('/', (req,res)=>{
    res.render('index', {data : {userQuery: req.params.userQuery}});
});

const PORT = process.env.PORT || 5000;


app.listen(PORT, ()=> console.log('Server started on port ${PORT}'));