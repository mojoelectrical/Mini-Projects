package com.example.michaelasafo_comp304_003_test01;

import androidx.appcompat.app.AppCompatActivity;
import androidx.constraintlayout.widget.ConstraintLayout;

import android.content.SharedPreferences;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.Button;
import android.app.Activity;
import android.view.View.OnClickListener;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import java.util.ArrayList;
import android.widget.ImageView;
import android.os.Bundle;
import android.graphics.Bitmap;
import android.graphics.RectF;
import android.graphics.drawable.BitmapDrawable;
import android.content.res.Resources;
import android.graphics.PointF;


public class Activity2 extends AppCompatActivity {

    private RadioGroup radioExerciseGroup;
    private RadioButton radioExerciseButton;
    private Button next;
    private Context mContext;
    private Resources mResources;
    private Button mButton;

    private ImageView mImageView;
    PointF pointA = new PointF(0,0);
    PointF pointB = new PointF(100,90);
    PointF pointC = new PointF(200,0);
    PointF pointD = new PointF(300,120);
    PointF pointE = new PointF(400,0);
    PointF pointF = new PointF(500,90);
    PointF pointG = new PointF(600,0);
    PointF pointH = new PointF(700,120);
    PointF pointI = new PointF(800,0);
    PointF pointJ = new PointF(900,90);
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_2);
        // Get the application context
        mContext = getApplicationContext();

        // Get the Resources
        mResources = getResources();


        mImageView = (ImageView) findViewById(R.id.ImageViewt);

        Bitmap bitmap = Bitmap.createBitmap(
                900, // Width
                130, // Height
                Bitmap.Config.ARGB_8888 // Config
        );

        // Initialize a new Canvas instance
        Canvas canvas = new Canvas(bitmap);

        // Draw a solid color on the canvas as background
        canvas.drawColor(Color.LTGRAY);

        // Initialize a new Paint instance to draw the line
        Paint paint = new Paint();
        // Line color
        paint.setColor(Color.RED);
        paint.setStyle(Paint.Style.STROKE);
        // Line width in pixels
        paint.setStrokeWidth(8);
        paint.setAntiAlias(true);

        canvas.drawLine(pointA.x,pointA.y,pointB.x,pointB.y,paint);
        canvas.drawLine(pointB.x,pointB.y,pointC.x,pointC.y,paint);
        canvas.drawLine(pointC.x,pointC.y,pointD.x,pointD.y,paint);
        canvas.drawLine(pointD.x,pointD.y,pointE.x,pointE.y,paint);
        canvas.drawLine(pointE.x,pointE.y,pointF.x,pointF.y,paint);
        canvas.drawLine(pointF.x,pointF.y,pointG.x,pointG.y,paint);
        canvas.drawLine(pointG.x,pointG.y,pointH.x,pointH.y,paint);
        canvas.drawLine(pointH.x,pointH.y,pointI.x,pointI.y,paint);
        canvas.drawLine(pointI.x,pointI.y,pointJ.x,pointJ.y,paint);

        // Display the newly created bitmap on app interface
        mImageView.setImageBitmap(bitmap);
        addListenerOnButton();

    }


    public void addListenerOnButton() {

        radioExerciseGroup = (RadioGroup) findViewById(R.id.exerciseGroup);
        next = (Button) findViewById(R.id.nextbutton);

        next.setOnClickListener(new OnClickListener() {

            @Override
            public void onClick(View v) {

                // get selected radio button from radioGroup
                int selectedId = radioExerciseGroup.getCheckedRadioButtonId();

                // find the radiobutton by returned id
                radioExerciseButton = (RadioButton) findViewById(selectedId);

                Toast.makeText(Activity2.this,
                        radioExerciseButton.getText(), Toast.LENGTH_SHORT).show();

            }

        });

    }

}