import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

class AccountTest{

public static void main(String[] args){

//created accounts
Account account1 = new Account("Mark",6700); //passed name an initial balances
Account account2 = new Account("Richard",4400); 
Account account3 = new Account("Lenny",300); 
Account account4 = new Account("Jenny",500); 
Account account5 = new Account("Ken", 256);


//creating instance of transactions
Transaction transaction1 = new Transaction("deposit",200,account1);
Transaction transaction2 = new Transaction("withdraw",90,account2);
Transaction transaction3 = new Transaction("deposit",49,account1);
Transaction transaction4 = new Transaction("withdraw",345,account3);
Transaction transaction5 = new Transaction("deposit",700,account4);

  ArrayList<Transaction> transactions = new ArrayList<Transaction>();
//adds array to list
  
  transactions.add(transaction1);
  transactions.add(transaction2);
  transactions.add(transaction3);
  transactions.add(transaction4);
  transactions.add(transaction5);
  
  ExecutorService Execute = Executors.newFixedThreadPool(5); //transactions in threadpool

          for (Transaction transaction:transactions) {
              Execute.execute(transaction);
            }
          Execute.shutdown();
          while (!Execute.isTerminated()) {
          }
}
}