class Transaction implements Runnable{

//set variables
private String transa; //transaction type
private double amount; //transaction amount
private Account account;//account call

//constructor
public Transaction(String transa,double amount,Account account){
this.transa = transa;
this.account = account;
this.amount = amount;

}

@Override
public void run() {

  if(transa.equalsIgnoreCase("withdraw"))
    account.withdraw(amount);
  else
    account.deposit(amount);

}

}