import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
class Account{

  //set variables
  private int accId; //id of the account
  private String name; //name
  private double balance; //balance
  private static int numAccounts = 0; //# of accounts

  //constructor
  public Account(String name,double initialBalance){
    this.name = name; 
    balance = initialBalance; 
    accId = ++numAccounts; 
    System.out.println("account ID: "+accId +", Name: "+name+" initial balance: "+balance);
  }

//withdraw method
  public synchronized void withdraw(double amt) {
    System.out.println("\n"+ name + " " + "is trying to withdraw $"+amt+" account"+accId);
      try {

          if (balance >= amt) {
              try {
                  Thread.sleep(90);
              } catch (Exception exp) {
                  exp.printStackTrace();
              }
              //updating the balance
              balance = balance - amt;
              System.out.println(name + " " + " withdrawed" + " Updated balance  : " + "$" +balance);
          } else {
              System.out.println(name + " " + "insufficient funds\n");
          }

      } catch (Exception exp) {
          exp.printStackTrace();
      }
  }

//deposit() method
  public synchronized void deposit(double depositAmt) {
    System.out.println("\n" + name + " deposited $"+depositAmt+" to account "+accId);
      try {
          if (depositAmt > 0) {
              try {
                  Thread.sleep(50);
              } catch (Exception exp) {
                  exp.printStackTrace();
              }
              balance = balance + depositAmt;
              System.out.println(name + " " + " successfully deposited" +"Current balance : $" + balance);
          } else {
              System.out.println(name + " " + "has insufficient funds");
          }
      } catch (Exception exp) {
          exp.printStackTrace();
      }
  }
}