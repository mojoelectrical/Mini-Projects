﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TweetE
{ 

    //Michael Asafo-Adjei
    //ID: 301110711
    //Centennial College
    //Course: Programming 2
    //Assignment 2
    //2020/10/23

    public class Tweet
        {
        private static int CURRENT_ID = 1;   
            private string From;
            private string To;
            private string Body;
            public string Tag;
            private string ID;
        // get methods
            public string from
            {
                get
                {
                    return this.From;
                }
            }

            public string to
            {
                get
                {
                    return this.To;
                }
            }

            public string body
            {
                get
                {
                    return this.Body;
                }
            }

            public string tag
            {
                get
                {
                    return this.Tag;
                }
            }

            public string Id
            {
                get
                {
                    return this.ID;
                }
            }




            public Tweet(string From, string To, string Body, string Tag)
            {
                this.From = From;
                this.To = To;
                this.Body = Body;
                this.Tag = Tag;
            }

            public Tweet(string From, string To, string Body, string Tag, string ID)
            {
                this.From = From;
                this.To = To;
                this.Body = Body;
                this.Tag = Tag;
                this.ID = ID;


                // Sets the Id property using the class variable CURRENT_ID.
                this.ID = CURRENT_ID.ToString();
                // the CURRENT_ID is incremented 
                CURRENT_ID++;
            }

            public override string ToString()
            {
                string body = this.Body;
                if (this.Body.Length > 40)
                    body = this.Body.Substring(0, 40);

                return string.Format("Tweet {0} {1} to {2} \n{3} \n#{4}\n",
                    this.ID, this.From, this.To, body, this.Tag);

            }
            public static Tweet Parse(string line)
            {   // parse the line
                string[] parseLine = line.Split(new char[] { '\t' });

                // if parse is successful
                if (parseLine.Length == 4)
                {
                    // for body and ID
                    string id = parseLine[3].Substring(parseLine[3].Length - 5);
                    string body = parseLine[3].Substring(0, parseLine[3].Length - 5);

                    // returns A tweet Object
                    return new Tweet(parseLine[0], parseLine[1], body, parseLine[2], id);
                }
                else
                {
                    return null;
                }
            }

        }
    }


