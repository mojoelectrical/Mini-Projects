﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//Michael Asafo-Adjei
//ID: 301110711
//Centennial College
//Course: Programming 2
//Assignment 2
//2020/10/23
namespace TweetE
{
    class TweetProgram
    {
        static public void Main(String[] args)
        {//initializes TweetManager and displays file data
            TweetManager.Initialize();
            TweetManager.ShowAll();
            Console.ReadLine();
        }



    }
}
