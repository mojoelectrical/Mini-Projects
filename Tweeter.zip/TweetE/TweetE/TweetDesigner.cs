﻿using System;
using System.Collections.Generic;
using System.IO;
//Michael Asafo-Adjei
//ID: 301110711
//Centennial College
//Course: Programming 2
//Assignment 2
//2020/10/23
namespace TweetE
{ 
	static class TweetManager
	{
		private static List<Tweet> TWEETS;
		private static string FILENAME;

		static TweetManager()
		{
			TWEETS = new List<Tweet>();                                                    //creates list
			FILENAME = @"C:\Users\micha\Desktop\Assignment_02_TweetFile.txt";              //inputs file
			try
			{
				using (StreamReader reader = new StreamReader(FILENAME))
				{
					while (!reader.EndOfStream)
					{
						string line = reader.ReadLine();
						Tweet tweet = Tweet.Parse(line);
						if (tweet != null)
							TWEETS.Add(tweet);
					}
				}
			}
			catch (Exception e)                                             //exception 
			{
				Console.WriteLine("Exception Occured!");
				Console.WriteLine(e.Message);
				Console.WriteLine("Calling TweetManager.Initialize..");
				Initialize();
			}
		}

		//initializes values
		public static void Initialize()
		{
			for (int i = 0; i < 5; ++i)
				TWEETS.Add(new Tweet($"From{i}", $"To{i}", $"Body{i}", $"Tag{i}"));
			for (int i = 0; i < 5; ++i)
				TWEETS.Add(new Tweet($"From{i}", $"To{i}", $"Body{i}", $"Tag{i}", $"Id{i}"));
		}

		public static void ShowAll()                          //shows all tweets 
		{
			foreach (var tweet in TWEETS)
			{
				Console.WriteLine(tweet);
				Console.WriteLine();
			}
		}

		public static void ShowAll(string tag)
		{
			foreach (var tweet in TWEETS)
			{
				if (tweet.Tag.ToLower() == tag.ToLower())
				{
					Console.WriteLine(tweet);
					Console.WriteLine();
				}
			}
		}
	}
}