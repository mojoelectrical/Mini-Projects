module newest {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	
	opens MichaelAsafo_sec005_ex01 to javafx.graphics, javafx.fxml;
}
