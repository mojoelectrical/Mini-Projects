
public class Address {
	//instance variables
	protected int houseNumber;
	protected String streetName;
	protected String City;
	protected String Province;
	protected String zipCode;
	
	//constructor 
	public Address(int houseNumber, String streetName, String City, String Province, String zipCode) {
		this.houseNumber=houseNumber;
		this.streetName=streetName;
		this.City=City;
		this.Province=Province;
		this.zipCode=zipCode;
	}
	
	
	// getter methods
	public String get_houseNumber() {
		
		String temp=Integer.toString(this.houseNumber);
		return temp;                                      //returns House Number
	}
	
	public String get_streetName() {
		return this.streetName;
	}
	
	public String get_City() {
		return this.City;                                  // returns City
	}
	
	public String get_Province() {
		return this.Province;                              //returns province
	}
	
	public String get_zipCode() {
		return this.zipCode;                               //returns zip code
	}
	
	//setters
	
	public void houseNumber(int houseNumber ) {
		this.houseNumber=houseNumber;                      //set House Number
	}
	
	public void streetName(String streetName) {
		this.streetName=streetName;                        //set Street Name
	}
	
	public void City(String City) {
		this.City=City;                                    //set City
	}
	
	public void Province(String Province) {
		this.Province=Province;                            //set Province
	}
	
	public void zipCode(String zipCode) {
		this.zipCode=zipCode;                              //sets zipCode
	}
	//displays all information
	public String toString(){
		return String.format("House Number: %s%nStreet Name: %s%nCity: %s%nProvince: %s%nZipCode: %s%n", get_houseNumber(), this.streetName, this.City, this.Province, this.zipCode);
	}
}
