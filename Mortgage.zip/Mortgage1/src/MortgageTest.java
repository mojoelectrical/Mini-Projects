/*
Name: Michael Asafo (301110711)
Midterm
2020-10-28
 */
public class MortgageTest {

	public static void main(String[] args) {
		//creates Mortgage area
		Mortgage mortgages[] = new Mortgage[2];
		//initializes mortgages
		mortgages[0]= new HomeMortgage(4342, "Mike", "12/12/2020","two lane", 500000, 0.04, 7,0.3, 0.3);
		mortgages[1]= new BusinessMortgage(32322, "Julian", "01/01/2020", "343 takoue", 23233, 0.02, 10, 100223);
		
		//Prints the Monthly mortgages
		/*
		System.out.println(mortgages[0].CalculateMonthlyMortgageInstallment());
		System.out.println(mortgages[1].CalculateMonthlyMortgageInstallment());
		*/
		//output
		System.out.println(mortgages[0].toString());
		System.out.println(mortgages[1].toString());


	}

}
