
public class BusinessMortgage extends Mortgage {
	//instance variables 
	protected double bizInsAmt;
	protected double sumNum;
	final int mortgageNumber;
	protected String customerName;
	protected String dateofBirth;
	protected String customerAddress;
	protected double mortgageAmt;
	protected double rateofinterest;
	protected double loanDuration; //years
	Address address= new Address(1,"Centennial Road","Toronto","Ontario","Y7T 9U8");
	
	//constructor
	public BusinessMortgage(int mortgageNumber, String customerName, String dateofBirth, String customerAddress, double mortgageAmt, double rateofinterest, double loanDuration, double bizInsAmt) {
		super(mortgageNumber,customerName,dateofBirth,customerAddress,mortgageAmt,rateofinterest, loanDuration);
		
		if (bizInsAmt < 0)
			throw new IllegalArgumentException("Business Insurance amount cannot be less than zero");
		
		this.bizInsAmt=bizInsAmt;
		this.mortgageNumber = mortgageNumber;
		this.customerName= customerName;
		this.dateofBirth = dateofBirth;
		this.customerAddress= customerAddress;
		this.mortgageAmt=mortgageAmt;
		this.rateofinterest=rateofinterest;
		this.loanDuration=loanDuration;
	}
	
	//Setter
	public void bizInsAmt(double bizInsAmt) {
		this.bizInsAmt=bizInsAmt;						//sets Business Insurance Amount
	}
	
	//Getter
	public double get_bizInsAmt() {
		return this.get_bizInsAmt();                    //gets Business Insurance Amount
	}
	
	
	
	//calculates monthly mortgage installment
	public double CalculateMonthlyMortgageInstallment() {
		sumNum = (this.mortgageAmt * (((rateofinterest/100)*loanDuration)/12) + this.bizInsAmt);
		return sumNum;
	}
	
	//displays information
	public String toString() {
		return String.format("Mortgage Number: %d%nCustomer Name: %s%nDOB: %s%nCustomer Address: %s%nMorgage Amount: %f%nRate of Interest: %f%nLoan Duration: %f%nBusiness Insurance: %f%nMonthly Mortage Installment: %f%n",super.get_mortgageNumber(), super.get_customerName(),super.get_dateofBirth(), super.get_customerAddress(), super.get_mortgageAmt(), super.get_rateofinterest(),super.get_loanDuration(),this.bizInsAmt,this.CalculateMonthlyMortgageInstallment());
	}
	
}
