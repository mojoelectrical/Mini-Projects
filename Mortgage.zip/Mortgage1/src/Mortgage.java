
public abstract class Mortgage {
	//instance variables
	final int mortgageNumber;
	protected String customerName;
	protected String dateofBirth;
	protected String customerAddress;
	protected double mortgageAmt;
	protected double rateofinterest;
	protected double loanDuration; //years
	Address address= new Address(1,"Centennial Road","Toronto","Ontario","Y7T 9U8");

	//constructors
	public Mortgage(int mortgageNumber, String customerName, String dateofBirth, String customerAddress, double mortgageAmt, double rateofinterest, double loanDuration) {
		
		if (mortgageAmt < 0)
			throw new IllegalArgumentException("Mortgage amount cannot be less than zero");
		
		if (rateofinterest < 0 || rateofinterest > 0.05) 
			throw new IllegalArgumentException("Interest rate cannot be less than zero or greater than 5%");
		
		
		this.mortgageNumber = mortgageNumber;
		this.customerName= customerName;
		this.dateofBirth = dateofBirth;
		this.customerAddress= customerAddress;
		this.mortgageAmt=mortgageAmt;
		this.rateofinterest=rateofinterest;
		this.loanDuration=loanDuration;
	}
	//constructor two
	public Mortgage(int mortgageNumber, String customerName, String dateofBirth, String customerAddress) {
		
		this.mortgageNumber=mortgageNumber;
		this.customerName=customerName;
		this.dateofBirth=dateofBirth;
		this.customerAddress=customerAddress;
	}
	
	// get methods
		public int get_mortgageNumber() {
			return this.mortgageNumber;							//get mortgage number
		}
		
		public String get_customerName() {
			return this.customerName;							//gets Customer Name
		}
		
		public String get_dateofBirth() {
			return this.dateofBirth;                            //gets Date of Birth
		}
		
		public String get_customerAddress() {
			return this.address.toString();                     //gets Customer Address
		}
		
		public double get_mortgageAmt(){
			return this.mortgageAmt;                            //gets Mortgage Amount
		}
		
		public double get_rateofinterest() {
			return this.rateofinterest;                          //gets Rate of Interest
		}
		
		public double get_loanDuration() {
			return this.loanDuration;                            //gets loan Duration
		}
		//setters
		public void customerName(String customerName) {
			this.customerName=customerName;                      //sets Customer Name
		}
		
		public void dateofBirth(String dateofBirth) {
			this.dateofBirth=dateofBirth;                        //sets Date of Birth
		}
		
		public void customerAddress(int houseNumber, String streetName, String City, String Province, String zipCode) {
			this.address=new Address(houseNumber, streetName, City, Province,zipCode);
		}
		
		public void mortgageAmt(double mortgageAmt) {
			if (mortgageAmt < 0)
				throw new IllegalArgumentException("Mortgage amount cannot be less than zero");
			this.mortgageAmt=mortgageAmt;
		}
		
		public void rateofinterest(double rateofinterest) {
			if (rateofinterest < 0 || rateofinterest > 0.05) 
				throw new IllegalArgumentException("Interest rate cannot be less than zero or greater than 5%");
			this.rateofinterest = rateofinterest;
		}
	//Calculates Monthly Mortgage Installment
		public abstract double CalculateMonthlyMortgageInstallment();
		
		public String toString() {
			return String.format("Mortgage Number: %d%nCustomer Name: %s%nDOB: %s%nCustomer Address: %s%nMortgage Amt: %f%nRate of Interest: %f%nLoan Duration: %f%n",get_mortgageNumber(), get_customerName(),get_dateofBirth(), get_customerAddress(), get_mortgageAmt(), get_rateofinterest(),get_loanDuration());
		}
		
}
