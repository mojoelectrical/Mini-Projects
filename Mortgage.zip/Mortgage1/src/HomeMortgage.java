
public class HomeMortgage extends Mortgage {
	//instance variables
	protected double propertyTax;
	protected double infrastructureTax;
	
	protected double sumNum;
	final int mortgageNumber;
	protected String customerName;
	protected String dateofBirth;
	protected String customerAddress;
	protected double mortgageAmt;
	protected double rateofinterest;
	protected double loanDuration; //years
	Address address= new Address(1,"Centennial Road","Toronto","Ontario","Y7T 9U8");
	//Home Mortgage constructor
	public HomeMortgage(int mortgageNumber, String customerName, String dateofBirth, String customerAddress, double mortgageAmt, double rateofinterest, double loanDuration,double propertyTax, double infrastructureTax) {
		super(mortgageNumber,customerName,dateofBirth,customerAddress,mortgageAmt,rateofinterest,loanDuration);
		
		if (propertyTax < 0.01)
			throw new IllegalArgumentException("Property Tax cannot be less than or equal to zero");
		if (infrastructureTax < 0.01)
			throw new IllegalArgumentException("Infrastructure Tax cannot be less than or equal to zero");
		
		
		this.propertyTax=propertyTax;
		this.propertyTax=infrastructureTax;
		
		this.mortgageNumber = mortgageNumber;
		this.customerName= customerName;
		this.dateofBirth = dateofBirth;
		this.customerAddress= customerAddress;
		this.mortgageAmt=mortgageAmt;
		this.rateofinterest=rateofinterest;
		this.loanDuration=loanDuration;
	}
	
	//setters
	public void propertytax(double propertyTax) {
		this.propertyTax=propertyTax;                               //sets Property Tax
	}
	
	public void infrastructureTax(double infrastructureTax) {
		this.infrastructureTax=infrastructureTax;                   //sets Infrastructure Tax
	}
	
	//get
	
	public double get_propertyTax() {
		return this.propertyTax;                                     //gets Property Tax
	}
	
	public double get_infrastureTax() {
		return this.infrastructureTax;								//gets Infrastructure Tax
	}
	
	//Calculates Month Mortgage Installment
	public double CalculateMonthlyMortgageInstallment() {
		//((mortgage amount * (rate of interest/100) * time) / 12 )
		
		sumNum = (this.mortgageAmt * ((((rateofinterest+this.propertyTax+this.infrastructureTax)/100)*loanDuration)/12)); //check calculations
		return sumNum;
	}
	//Displays information
	public String toString() {
		return String.format("Mortgage Number: %d%nCustomer Name: %s%nDOB: %s%nCustomer Address: %s%ninitial Mortgage Amount: %f%nRate Interest: %f%nLoan Duration: %fyrs%nProperty Tax: %f%nInfrastructure Tax: %f%nMortgage Monthly Installment: %f%n",super.get_mortgageNumber(), super.get_customerName(),super.get_dateofBirth(), super.get_customerAddress(), super.get_mortgageAmt(), super.get_rateofinterest(),super.get_loanDuration(),this.propertyTax,this.infrastructureTax,this.CalculateMonthlyMortgageInstallment());
	}
	
}
