package com.example.leaseorrenthomeincorporated;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.widget.Button;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

public class CheckOut extends AppCompatActivity {
    @SuppressLint("ResourceType")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_check_out);
        TextView noOptionsMessage = (TextView)findViewById(R.id.noOptionsMessage);
        noOptionsMessage.setVisibility(View.INVISIBLE);

        SharedPreferences myPref =
                getSharedPreferences("info", MODE_PRIVATE);
        boolean apt1selected = myPref.getBoolean("apt1selected", false);
        boolean apt2selected = myPref.getBoolean("apt2selected", false);
        boolean apt3selected = myPref.getBoolean("apt3selected", false);
        boolean apt4selected = myPref.getBoolean("apt4selected", false);
        boolean apt5selected = myPref.getBoolean("apt5selected", false);
        boolean apt6selected = myPref.getBoolean("apt6selected", false);
        boolean apt7selected = myPref.getBoolean("apt7selected", false);
        boolean apt8selected = myPref.getBoolean("apt8selected", false);

        boolean condo1selected = myPref.getBoolean("condo1selected", false);
        boolean condo2selected = myPref.getBoolean("condo2selected", false);
        boolean condo3selected = myPref.getBoolean("condo3selected", false);
        boolean condo4selected = myPref.getBoolean("condo4selected", false);
        boolean condo5selected = myPref.getBoolean("condo5selected", false);

        boolean detached1selected = myPref.getBoolean("detached1selected", false);
        boolean detached2selected = myPref.getBoolean("detached2selected", false);
        boolean detached3selected = myPref.getBoolean("detached3selected", false);
        boolean detached4selected = myPref.getBoolean("detached4selected", false);
        boolean detached5selected = myPref.getBoolean("detached5selected", false);


        boolean semi1selected = myPref.getBoolean("semi1selected", false);
        boolean semi2selected = myPref.getBoolean("semi2selected", false);

        boolean townhouse1selected = myPref.getBoolean("townhouse1selected", false);
        boolean townhouse2selected = myPref.getBoolean("townhouse2selected", false);


        boolean options_exist=false;
        RadioGroup rg = (RadioGroup) findViewById(R.id.rg_homes);


        if (apt1selected){
            RadioButton rb1 = new RadioButton(this);
            rb1.setText("Apartment 1");
            rb1.setId(1);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb1, params);
            options_exist=true;
        }
        if (apt2selected) {
            RadioButton rb2 = new RadioButton(this);
            rb2.setText("Apartment 2");
            rb2.setId(2);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb2, params);
            options_exist = true;
        }
        if (apt3selected){
            RadioButton rb3 = new RadioButton(this);
            rb3.setText("Apartment 3");
            rb3.setId(3);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb3, params);
            options_exist=true;
        }


        if (apt4selected){
            RadioButton rb4 = new RadioButton(this);
            rb4.setText("Apartment 4");
            rb4.setId(4);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb4, params);
            options_exist=true;

    }
        if (apt5selected){
            RadioButton rb5 = new RadioButton(this);
            rb5.setText("Apartment 5");
            rb5.setId(5);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb5, params);
            options_exist=true;
        }
        if (apt6selected) {
            RadioButton rb6 = new RadioButton(this);
            rb6.setText("Apartment 6");
            rb6.setId(6);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb6, params);
            options_exist = true;
        }
        if (apt7selected){
            RadioButton rb7 = new RadioButton(this);
            rb7.setText("Apartment 7");
            rb7.setId(7);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb7, params);
            options_exist=true;
        }

        if (apt8selected){
            RadioButton rb8 = new RadioButton(this);
            rb8.setText("Apartment 8");
            rb8.setId(8);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb8, params);
            options_exist=true;
        }
        if (condo1selected){
            RadioButton rb9 = new RadioButton(this);
            rb9.setText("Condo 1");
            rb9.setId(9);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb9, params);
            options_exist=true;
        }
        if (condo2selected){
            RadioButton rb10 = new RadioButton(this);
            rb10.setText("Condo 2");
            rb10.setId(10);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb10, params);
            options_exist=true;
        }
        if (condo3selected){
            RadioButton rb11 = new RadioButton(this);
            rb11.setText("Condo 3");
            rb11.setId(11);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb11, params);
            options_exist=true;
        }
        if (condo4selected){
            RadioButton rb12 = new RadioButton(this);
            rb12.setText("Condo 4");
            rb12.setId(12);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb12, params);
            options_exist=true;
        }
        if (condo5selected){
            RadioButton rb13 = new RadioButton(this);
            rb13.setText("Condo 5");
            rb13.setId(13);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb13, params);
            options_exist=true;
        }



        if (detached1selected){
            RadioButton rb14 = new RadioButton(this);
            rb14.setText("Detached Home 1");
            rb14.setId(14);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb14, params);
            options_exist=true;
        }

        if (detached2selected){
            RadioButton rb15 = new RadioButton(this);
            rb15.setText("Detached Home 2");
            rb15.setId(15);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb15, params);
            options_exist=true;
        }

        if (detached3selected){
            RadioButton rb16 = new RadioButton(this);
            rb16.setText("Detached Home 3");
            rb16.setId(16);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb16, params);
            options_exist=true;
        }

        if (detached4selected){
            RadioButton rb17 = new RadioButton(this);
            rb17.setText("Detached Home 4");
            rb17.setId(17);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb17, params);
            options_exist=true;
        }

        if (detached5selected){
            RadioButton rb18 = new RadioButton(this);
            rb18.setText("Detached Home 4");
            rb18.setId(18);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb18, params);
            options_exist=true;
        }



        if (semi1selected){
            RadioButton rb19 = new RadioButton(this);
            rb19.setText("Semi-Detached Home 1");
            rb19.setId(19);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb19, params);
            options_exist=true;
        }

        if (semi2selected){
            RadioButton rb20 = new RadioButton(this);
            rb20.setText("Semi-Detached Home 2");
            rb20.setId(20);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb20, params);
            options_exist=true;
        }
        if (townhouse1selected){
            RadioButton rb21 = new RadioButton(this);
            rb21.setText("Townhouse 1");
            rb21.setId(21);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb21, params);
            options_exist=true;
        }

        if (townhouse2selected){
            RadioButton rb22 = new RadioButton(this);
            rb22.setText("Townhouse 2");
            rb22.setId(22);
            RadioGroup.LayoutParams params = new RadioGroup.LayoutParams(RadioGroup.LayoutParams.WRAP_CONTENT, RadioGroup.LayoutParams.WRAP_CONTENT);
            rg.addView(rb22, params);
            options_exist=true;
        }
        if (!options_exist){
            Button PayOpt_button = (Button)findViewById(R.id.PayOpt_button);
            PayOpt_button.setVisibility(View.INVISIBLE);
            noOptionsMessage.setVisibility(View.VISIBLE);

        }
    }

    public void PayOpt_click(View view) {
        RadioGroup radioGroup = findViewById(R.id.rg_homes);
        int selectedId = radioGroup.getCheckedRadioButtonId();

        if (selectedId==-1){
            Toast.makeText(this, "No option chosen", Toast.LENGTH_SHORT).show();
        }
        else {
            RadioButton radioButton = (RadioButton) findViewById(selectedId);
            String chosen_home = (String)radioButton.getText();
            SharedPreferences myPreference =
                    getSharedPreferences("info", 0);
            SharedPreferences.Editor prefEditor = myPreference.edit();
            prefEditor.putString("chosen_home", chosen_home);
            prefEditor.commit();

            Intent intent = new Intent(this, PaymentOption.class);
            startActivity(intent);
        }
    }
}