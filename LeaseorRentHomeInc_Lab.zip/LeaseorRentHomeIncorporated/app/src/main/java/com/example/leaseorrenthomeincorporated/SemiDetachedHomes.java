package com.example.leaseorrenthomeincorporated;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;

public class SemiDetachedHomes extends AppCompatActivity {
    private CheckBox semidetached1, semidetached2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_semi_detached_homes);
        semidetached1=findViewById(R.id.semi1Box);
        semidetached2=findViewById(R.id.semi2Box);
    }

    public void selected_box(View view){
        SharedPreferences myPreference = getSharedPreferences("info",0);
        SharedPreferences.Editor prefEditor=myPreference.edit();

        //checking and saving info from checkboxes
        boolean semi1selected = semidetached1.isChecked();
        boolean semi2selected = semidetached2.isChecked();
        prefEditor.putBoolean("semi1selected", semi1selected);
        prefEditor.putBoolean("semi2selected", semi2selected);
        prefEditor.commit();
        Toast.makeText(this, "Added to Checkout",Toast.LENGTH_SHORT).show();
    }

    public void goto_checkout(View view){
        selected_box(view);
        Intent intent = new Intent(this, CheckOut.class);
        startActivity(intent);
    }


    //OPtion Menu
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.rent_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //handle item selection
        switch (item.getItemId()){
            case R.id.apartments:
                Toast.makeText(this, "Apartment",Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, Apartments.class);
                startActivity(intent1);
                break;

            case R.id.detachedhomes:
                Toast.makeText(this, "Detached Home", Toast.LENGTH_SHORT).show();
                Intent intent2= new Intent(this, DetachedHomes.class);
                startActivity(intent2);
                break;

            case R.id.condominiums:
                Toast.makeText(this, "Condo", Toast.LENGTH_SHORT).show();
                Intent intent3= new Intent(this, Condominiums.class);
                startActivity(intent3);
                break;

            case R.id.semidetachedhomes:
                Toast.makeText(this, "Semi-Detached Homes", Toast.LENGTH_SHORT).show();
                Intent intent4= new Intent(this, SemiDetachedHomes.class);
                startActivity(intent4);
                break;

            case R.id.townhouses:
                Toast.makeText(this,"Townhouses",Toast.LENGTH_SHORT).show();
                Intent intent5= new Intent(this, Townhouses.class);
                startActivity(intent5);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}