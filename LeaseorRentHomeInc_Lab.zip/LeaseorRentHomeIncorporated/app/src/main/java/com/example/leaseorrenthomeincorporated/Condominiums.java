package com.example.leaseorrenthomeincorporated;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import android.content.SharedPreferences;

public class Condominiums extends AppCompatActivity {
    private CheckBox condo1checkbox, condo2checkbox, condo3checkbox, condo4checkbox, condo5checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        condo1checkbox=findViewById(R.id.condo1checkBox);
        condo2checkbox=findViewById(R.id.condo2checkBox);
        condo3checkbox=findViewById(R.id.condo3checkBox);
        condo4checkbox=findViewById(R.id.condo4checkBox);
        condo5checkbox=findViewById(R.id.condo5checkBox);
        setContentView(R.layout.activity_condominiums);
    }

    public void selected_box(View view){
        SharedPreferences myPreference = getSharedPreferences("info",0);
        SharedPreferences.Editor prefEditor=myPreference.edit();

        //checking and saving info from checkboxes
        boolean condo1selected = condo1checkbox.isChecked();
        boolean condo2selected = condo2checkbox.isChecked();
        boolean condo3selected = condo3checkbox.isChecked();
        boolean condo4selected = condo4checkbox.isChecked();
        boolean condo5selected = condo5checkbox.isChecked();
        prefEditor.putBoolean("condo1selected", condo1selected);
        prefEditor.putBoolean("condo2selected", condo2selected);
        prefEditor.putBoolean("condo3selected", condo3selected);
        prefEditor.putBoolean("condo4selected", condo4selected);
        prefEditor.putBoolean("condo5selected", condo5selected);
        prefEditor.commit();
        Toast.makeText(this, "Added to Checkout",Toast.LENGTH_SHORT).show();
    }

    public void goto_checkout(View view){
        selected_box(view);
        Intent intent = new Intent(this, CheckOut.class);
        startActivity(intent);
    }

    //OPtion Menu
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.rent_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //handle item selection
        switch (item.getItemId()){
            case R.id.apartments:
                Toast.makeText(this, "Apartment",Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, Apartments.class);
                startActivity(intent1);
                break;

            case R.id.detachedhomes:
                Toast.makeText(this, "Detached Home", Toast.LENGTH_SHORT).show();
                Intent intent2= new Intent(this, DetachedHomes.class);
                startActivity(intent2);
                break;

            case R.id.condominiums:
                Toast.makeText(this, "Condo", Toast.LENGTH_SHORT).show();
                Intent intent3= new Intent(this, Condominiums.class);
                startActivity(intent3);
                break;

            case R.id.semidetachedhomes:
                Toast.makeText(this, "Semi-Detached Homes", Toast.LENGTH_SHORT).show();
                Intent intent4= new Intent(this, SemiDetachedHomes.class);
                startActivity(intent4);
                break;

            case R.id.townhouses:
                Toast.makeText(this,"Townhouses",Toast.LENGTH_SHORT).show();
                Intent intent5= new Intent(this, Townhouses.class);
                startActivity(intent5);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}