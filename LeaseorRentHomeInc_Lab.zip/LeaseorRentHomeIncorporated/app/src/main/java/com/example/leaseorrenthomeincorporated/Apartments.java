package com.example.leaseorrenthomeincorporated;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.content.Intent;
import android.view.MenuItem;
import android.view.View;
import android.widget.CheckBox;
import android.widget.Toast;
import android.content.SharedPreferences;

public class Apartments extends AppCompatActivity {
    private CheckBox apt1checkbox, apt2checkbox, apt3checkbox, apt4checkbox, apt5checkbox, apt6checkbox,
    apt7checkbox, apt8checkbox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_apartments);
        apt1checkbox=findViewById(R.id.apt1checkBox);
        apt2checkbox=findViewById(R.id.apt2checkBox);
        apt3checkbox=findViewById(R.id.apt3checkBox);
        apt4checkbox=findViewById(R.id.apt4checkBox);
        apt5checkbox=findViewById(R.id.apt5checkBox);
        apt6checkbox=findViewById(R.id.apt6checkBox);
        apt7checkbox=findViewById(R.id.apt7checkBox);
        apt8checkbox=findViewById(R.id.apt8checkBox);
    }

    public void selected_box(View view){
        SharedPreferences myPreference = getSharedPreferences("info",0);
        SharedPreferences.Editor prefEditor=myPreference.edit();

        //checking and saving info from checkboxes
        boolean apt1selected = apt1checkbox.isChecked();
        boolean apt2selected = apt2checkbox.isChecked();
        boolean apt3selected = apt3checkbox.isChecked();
        boolean apt4selected = apt4checkbox.isChecked();
        boolean apt5selected = apt5checkbox.isChecked();
        boolean apt6selected = apt6checkbox.isChecked();
        boolean apt7selected = apt7checkbox.isChecked();
        boolean apt8selected = apt8checkbox.isChecked();
        prefEditor.putBoolean("apt1selected", apt1selected);
        prefEditor.putBoolean("apt2selected", apt2selected);
        prefEditor.putBoolean("apt3selected", apt3selected);
        prefEditor.putBoolean("apt4selected", apt4selected);
        prefEditor.putBoolean("apt5selected", apt5selected);
        prefEditor.putBoolean("apt6selected", apt6selected);
        prefEditor.putBoolean("apt7selected", apt7selected);
        prefEditor.putBoolean("apt8selected", apt8selected);
        prefEditor.commit();
        Toast.makeText(this, "Added to Checkout",Toast.LENGTH_SHORT).show();
    }

    public void goto_checkout(View view){
        selected_box(view);
        Intent intent = new Intent(this, CheckOut.class);
        startActivity(intent);
    }

    //OPtion Menu
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.rent_menu, menu);
        return true;
    }

    public boolean onOptionsItemSelected(MenuItem item){
        //handle item selection
        switch (item.getItemId()){
            case R.id.apartments:
                Toast.makeText(this, "Apartment",Toast.LENGTH_SHORT).show();
                Intent intent1 = new Intent(this, Apartments.class);
                startActivity(intent1);
                break;

            case R.id.detachedhomes:
                Toast.makeText(this, "Detached Home", Toast.LENGTH_SHORT).show();
                Intent intent2= new Intent(this, DetachedHomes.class);
                startActivity(intent2);
                break;

            case R.id.condominiums:
                Toast.makeText(this, "Condo", Toast.LENGTH_SHORT).show();
                Intent intent3= new Intent(this, Condominiums.class);
                startActivity(intent3);
                break;

            case R.id.semidetachedhomes:
                Toast.makeText(this, "Semi-Detached Homes", Toast.LENGTH_SHORT).show();
                Intent intent4= new Intent(this, SemiDetachedHomes.class);
                startActivity(intent4);
                break;

            case R.id.townhouses:
                Toast.makeText(this,"Townhouses",Toast.LENGTH_SHORT).show();
                Intent intent5= new Intent(this, Townhouses.class);
                startActivity(intent5);
                break;
            default:
                return super.onOptionsItemSelected(item);
        }
        return true;
    }
}


