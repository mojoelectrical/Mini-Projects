module newest {
	requires javafx.controls;
	requires javafx.fxml;
	requires javafx.base;
	requires java.sql;
	requires mysql.connector.java;
	
	
	opens MichaelAsafo_sec005_Student to javafx.graphics, javafx.fxml;
}
