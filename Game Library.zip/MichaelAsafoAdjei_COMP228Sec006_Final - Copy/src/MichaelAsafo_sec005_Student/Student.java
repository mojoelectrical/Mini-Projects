package MichaelAsafo_sec005_Student;

public class Student {
//set variables
	String studentID;
	String firstName;
	String lastName;
	String address;
	String city;
	String province;
	String postalCode;
	//create constructor
	public Student(String studentID, String firstName, String lastName, String address, String city, String province, String postalCode) {
		this.studentID=studentID;
		this.firstName=firstName;
		this.lastName=lastName;
		this.address=address;
		this.city=city;
		this.province=province;
		this.postalCode=postalCode;
	}
	
	
	//setters
	public void set_studentID(String studentID) {
		this.studentID=studentID;
	}
	
	public void set_firstName(String first) {
		this.firstName=first;
	}
	
	public void set_lastName(String last) {
		this.lastName=last;
	}
	
	public void set_address(String address) {
		this.address=address;
	}
	
	public void set_city(String city) {
		this.city=city;
	}
	
	public void set_province(String province) {
		this.province=province;
	}
	
	public void set_postalCode(String postalCode) {
		this.postalCode=postalCode;
	}
}
