package MichaelAsafo_sec005_Student;

import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.fxml.FXMLLoader;

import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.sql.Connection;
import java.sql.Statement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Connection;
import java.sql.PreparedStatement;

//sets scene, window of scenebuilder size
public class Main extends Application {
	@Override
	public void start(Stage primaryStage) {
		try {
			Parent root = FXMLLoader.load(getClass().getResource("gameshmk.fxml"));
			Scene scene = new Scene(root,700,550);
			//scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();
		} catch(Exception e) {
			e.printStackTrace();
		}
	}
	
	
	void createConnection() {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gamesdb?autoReconnect=true&useSSL=false","root","sqljava");
			System.out.println("System is connected");
		
			Statement stmt=con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM student");
			
			while (rs.next()) {
				String studentID = rs.getString("studentID");
				String firstName = rs.getString("firstName");
				String lastName= rs.getString("lastName");
				String address=rs.getString("address");
				String city=rs.getString("city");
				String province=rs.getString("province");
				String postalcode=rs.getString("postalCode");
			}
			stmt.close();
		} catch (ClassNotFoundException ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
		} catch (SQLException ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null,ex);
		}
	
	}
	
	public static void main(String[] args) {
		launch(args);
		Main pro = new Main();
		pro.createConnection();	
	}

}
