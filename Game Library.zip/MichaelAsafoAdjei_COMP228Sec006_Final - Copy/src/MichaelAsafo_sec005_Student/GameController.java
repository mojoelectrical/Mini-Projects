package MichaelAsafo_sec005_Student;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Random;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;

import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;  


import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextField;
import java.util.Random;

public class GameController implements Initializable{
	
	ObservableList<Student> studentList= FXCollections.observableArrayList();
	ObservableList<Student> indexes= FXCollections.observableArrayList();

	String total;
	Connection con;
    @FXML
    private TextArea studentinfo;
    
    @FXML
    private TextField inputText;

    @FXML
    private Button submit_btn;
    

//filters the text area if input matches input.text and sets //string after adding lines to textarea using setText and //iterating the student objects
    @FXML
    void submit_clk(ActionEvent event) {
    	String[] arrayz;
    	String formatted = "";
    	String ot;
    	String neww="";
    	indexes.clear();
    	studentList.clear();
    	total="";
    	initi();
    	for (Student indexed:studentList) {
    		if ((indexed.city).toLowerCase().equals(inputText.getText().toLowerCase())) {
    			indexes.add(indexed);
    			System.out.println("Added to list");
    			
    		}
    	}
    	studentinfo.clear();
    	for (Student printIt:indexes) {
    		total += printIt.studentID + "\t" + printIt.firstName + "\t" + printIt.lastName + "\t\t" + printIt.address + "\t" + printIt.city + "\t"+ printIt.province + "\t" + printIt.postalCode +"\n";
    	
    		formatted += String.format("%-20s%-20s%-20s%-30s%-12s%-15s%-12s \n",printIt.studentID ,printIt.firstName, printIt.lastName, printIt.address, printIt.city, printIt.province, printIt.postalCode);
    		
    			studentinfo.setText(total);
    		}
    	
    	
    	if (inputText.getText().equals("")) {
			initi();
    	
    
    }
    }
    
    public void initialize(URL location, ResourceBundle resources) {
    	//TODO Auto-generated method stub
    	initi(); //initializes databases
    }
    //connects to the databases and initializes the textarea
    public void initi() {
    	try {
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/gamesdb?autoReconnect=true&useSSL=false","root","sqljava");
			Statement stmt = con.createStatement();
			ResultSet rs = stmt.executeQuery("SELECT * FROM student");
		String all_ = "";


			while (rs.next()) {
				String studentID = rs.getString("studentID");
				String firstName = rs.getString("firstName");
				String lastName= rs.getString("lastName");
				String address=rs.getString("address");
				String city=rs.getString("city");
				String province=rs.getString("province");
				String postalcode=rs.getString("postalCode");
				Student newStudent = new Student(studentID, firstName, lastName, address, city, province, postalcode);
				studentList.add(newStudent);
				all_ += String.valueOf(studentID) +"\t" + firstName +"\t"+lastName+"\t"+address+"\t\t"+city+"\t"+ province+"\t" +postalcode + "\n";
				
			studentinfo.setText(all_);
		    	
				
		}}catch (SQLException ex) {
			Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null,ex);
		}
    	
    }
    	
}	
			
	